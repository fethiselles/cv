import { useReveal } from '../lib/useReveal'

export function Contact() {
  const ref = useReveal<HTMLDivElement>()
  return (
    <section id="contact" className="scroll-mt-24 bg-ink py-24 text-white md:py-36">
      <div ref={ref} className="reveal mx-auto max-w-[1240px] px-6 md:px-10">
        <div className="flex items-baseline gap-3">
          <span className="font-mono text-sm text-blush">05</span>
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-white/50">Contact</span>
        </div>

        <h2 className="mt-6 max-w-4xl font-display text-[clamp(2.5rem,7vw,6rem)] font-extrabold leading-[0.95] tracking-[-0.03em]">
          Construisons quelque chose
          <br />
          de <span className="text-blush">significatif.</span>
        </h2>

        <p className="mt-8 max-w-xl text-lg leading-relaxed text-white/60">
          Disponible pour les opportunités et collaborations. Je réponds à chaque message —
          écrivons la suite ensemble.
        </p>

        <ul className="mt-8 flex flex-wrap gap-2.5">
          {[
            'Stages & internats',
            'Partenariats',
            'Projets scientifiques',
            'Événements',
            'Recherche',
            'Collaborations',
          ].map((x) => (
            <li
              key={x}
              className="rounded-full border border-white/15 px-4 py-1.5 font-mono text-xs uppercase tracking-wider text-white/70"
            >
              {x}
            </li>
          ))}
        </ul>

        <div className="mt-14 grid gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/10 sm:grid-cols-3">
          <a
            href="mailto:fethi.selles@univ-alger.dz"
            className="group bg-ink p-8 transition-colors hover:bg-crimson"
          >
            <div className="font-mono text-xs uppercase tracking-wider text-white/50 group-hover:text-white/80">
              Email
            </div>
            <div className="mt-3 font-display text-lg font-semibold">Écrire un message</div>
            <div className="mt-1 break-all text-sm text-white/60 group-hover:text-white/90">
              fethi.selles@univ-alger.dz
            </div>
          </a>
          <a
            href="https://linkedin.com/in/fethi-selles-b22201329"
            target="_blank"
            rel="noreferrer"
            className="group bg-ink p-8 transition-colors hover:bg-crimson"
          >
            <div className="font-mono text-xs uppercase tracking-wider text-white/50 group-hover:text-white/80">
              LinkedIn
            </div>
            <div className="mt-3 font-display text-lg font-semibold">fethi-selles</div>
            <div className="mt-1 text-sm text-white/60 group-hover:text-white/90">
              Réseau professionnel
            </div>
          </a>
          <a href="tel:+213668736430" className="group bg-ink p-8 transition-colors hover:bg-crimson">
            <div className="font-mono text-xs uppercase tracking-wider text-white/50 group-hover:text-white/80">
              Téléphone
            </div>
            <div className="mt-3 font-display text-lg font-semibold">Appeler</div>
            <div className="mt-1 text-sm text-white/60 group-hover:text-white/90">
              06 68 73 64 30
            </div>
          </a>
        </div>

        <footer className="mt-20 flex flex-col gap-4 border-t border-white/10 pt-8 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2.5">
            <span className="grid h-7 w-7 place-items-center rounded-full bg-crimson font-display text-xs font-bold">
              FS
            </span>
            <span className="font-display text-sm font-semibold">Fethi Selles</span>
          </div>
          <p className="font-mono text-xs uppercase tracking-wider text-white/40">
            Alger, Algérie · Médecine × Technologie × Communication · © 2026
          </p>
        </footer>
      </div>
    </section>
  )
}
