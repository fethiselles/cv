import { useReveal } from '../lib/useReveal'
import { SectionHeader } from './SectionHeader'

const PILLARS = [
  {
    t: 'Médecine',
    d: "Externe formé sur le terrain hospitalier. La méthode scientifique guide ma façon d'observer, de décider et de rendre compte.",
  },
  {
    t: 'Technologie',
    d: 'Bio-informatique médicale, prompt engineering et design graphique : je mobilise le numérique pour donner corps aux idées.',
  },
  {
    t: 'Communication',
    d: "Interface des partenaires, sponsors et institutions. Je traduis le complexe en messages clairs et négocie avec diplomatie.",
  },
  {
    t: 'Leadership',
    d: "Représentation étudiante, management d'équipe et sport de haut niveau : discipline, esprit collectif et gestion de la pression.",
  },
]

export function About() {
  const ref = useReveal<HTMLDivElement>()
  return (
    <section id="about" className="scroll-mt-24 py-24 md:py-32">
      <div ref={ref} className="reveal mx-auto max-w-[1240px] px-6 md:px-10">
        <SectionHeader
          index="01"
          eyebrow="Profil"
          title={<>Quatre disciplines, une même exécution.</>}
        >
          <p className="text-lg leading-relaxed text-muted">
            Mon profil se lit à l'intersection de quatre domaines. C'est leur combinaison — rare et
            crédible — qui fait ma différence : transformer la curiosité scientifique en projets
            concrets, et les projets en relations durables.
          </p>
        </SectionHeader>

        <div className="mt-16 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2">
          {PILLARS.map((p, i) => (
            <div
              key={p.t}
              className="group bg-paper p-8 transition-colors hover:bg-mist md:p-10"
            >
              <span className="font-mono text-xs text-crimson">0{i + 1}</span>
              <h3 className="mt-4 font-display text-xl font-semibold tracking-tight">{p.t}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">{p.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
