const DISCIPLINES = [
  'Médecine',
  'Bio-informatique',
  'Communication scientifique',
  'Leadership',
  'Événementiel',
]

export function Proof() {
  return (
    <section aria-label="Domaines d'expertise" className="border-y border-line bg-mist">
      <div className="mx-auto max-w-[1240px] px-6 md:px-10">
        <ul className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3 py-6 md:justify-between md:py-7">
          {DISCIPLINES.map((d) => (
            <li
              key={d}
              className="flex items-center gap-2.5 font-display text-sm font-semibold tracking-tight text-ink md:text-base"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-crimson" aria-hidden />
              {d}
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
