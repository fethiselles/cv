import { useEffect, useState } from 'react'
import { useActiveSection, useScrollProgress } from '../lib/useReveal'

const LINKS = [
  { id: 'about', label: 'Profil' },
  { id: 'experience', label: 'Parcours' },
  { id: 'skills', label: 'Compétences' },
  { id: 'education', label: 'Formation' },
  { id: 'contact', label: 'Contact' },
]

export function Nav() {
  const active = useActiveSection(['home', ...LINKS.map((l) => l.id)])
  const progress = useScrollProgress()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'border-b border-line bg-paper/85 backdrop-blur-md'
          : 'border-b border-transparent'
      }`}
    >
      <div className="mx-auto flex max-w-[1240px] items-center justify-between px-6 py-4 md:px-10">
        <a href="#home" className="group flex items-center gap-2.5" aria-label="Retour en haut">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-crimson font-display text-sm font-bold text-white transition-transform duration-300 group-hover:scale-105">
            FS
          </span>
          <span className="hidden font-display text-sm font-semibold tracking-tight sm:block">
            Fethi Selles
          </span>
        </a>

        <nav className="hidden items-center gap-1 md:flex">
          {LINKS.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              className={`relative rounded-full px-3.5 py-2 font-mono text-xs uppercase tracking-wider transition-colors ${
                active === l.id ? 'text-crimson' : 'text-muted hover:text-ink'
              }`}
            >
              {l.label}
              <span
                className={`absolute inset-x-3.5 -bottom-0.5 h-px origin-left bg-crimson transition-transform duration-300 ${
                  active === l.id ? 'scale-x-100' : 'scale-x-0'
                }`}
              />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#contact"
            className="hidden rounded-full bg-ink px-4 py-2 font-mono text-xs uppercase tracking-wider text-white transition-colors hover:bg-crimson md:inline-block"
          >
            Contact
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            aria-label="Menu"
            aria-expanded={open}
            className="grid h-9 w-9 place-items-center rounded-full border border-line md:hidden"
          >
            <span className="relative block h-3 w-4">
              <span
                className={`absolute left-0 h-0.5 w-4 bg-ink transition-all ${open ? 'top-1.5 rotate-45' : 'top-0'}`}
              />
              <span
                className={`absolute left-0 top-1.5 h-0.5 w-4 bg-ink transition-all ${open ? 'opacity-0' : 'opacity-100'}`}
              />
              <span
                className={`absolute left-0 h-0.5 w-4 bg-ink transition-all ${open ? 'top-1.5 -rotate-45' : 'top-3'}`}
              />
            </span>
          </button>
        </div>
      </div>

      {/* Scroll progress */}
      <div className="absolute inset-x-0 bottom-0 h-0.5 bg-transparent" aria-hidden>
        <div
          className="h-full origin-left bg-crimson transition-transform duration-150 ease-out"
          style={{ transform: `scaleX(${progress})` }}
        />
      </div>

      {/* Mobile drawer */}
      <div
        className={`overflow-hidden border-t border-line bg-paper transition-[max-height] duration-300 md:hidden ${
          open ? 'max-h-96' : 'max-h-0 border-t-transparent'
        }`}
      >
        <nav className="flex flex-col px-6 py-2">
          {LINKS.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              onClick={() => setOpen(false)}
              className="border-b border-line/60 py-3 font-display text-lg font-medium last:border-0"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="mt-3 mb-3 rounded-full bg-ink py-3 text-center font-mono text-xs uppercase tracking-wider text-white"
          >
            Contact
          </a>
        </nav>
      </div>
    </header>
  )
}
