import { useReveal } from '../lib/useReveal'
import portrait from '../assets/fethi.png'

const STATS = [
  { k: '18,14/20', v: 'Baccalauréat scientifique' },
  { k: '2023', v: "Vice-champion d'Algérie · volley" },
  { k: '3', v: 'Rôles en relations & événementiel' },
]

export function Hero() {
  const ref = useReveal<HTMLDivElement>()
  return (
    <section id="home" className="relative overflow-hidden pt-32 md:pt-40">
      {/* Organic brand field */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-32 -top-24 h-[520px] w-[520px] rounded-full bg-crimson/8 blur-3xl"
      />

      <div ref={ref} className="reveal mx-auto max-w-[1240px] px-6 md:px-10">
        <p className="flex items-center gap-2 font-mono text-xs uppercase tracking-[0.2em] text-muted">
          <span className="h-1.5 w-1.5 rounded-full bg-crimson" />
          Alger, Algérie — Ouvert aux collaborations
        </p>

        {/* Name + portrait */}
        <div className="mt-6 flex items-center justify-between gap-6 sm:gap-10">
          <h1 className="min-w-0 font-display text-[clamp(3.25rem,11vw,7.25rem)] font-extrabold leading-[0.88] tracking-[-0.03em]">
            Fethi
            <br />
            <span className="text-crimson">Selles</span>
          </h1>

          <figure className="group relative shrink-0">
            {/* Organic brand field behind the portrait */}
            <span
              aria-hidden
              className="absolute -inset-3 -z-10 rounded-[46%_54%_58%_42%/52%_46%_54%_48%] bg-crimson/10 transition-transform duration-700 ease-out group-hover:rotate-6 sm:-inset-4"
            />
            <div className="relative aspect-square w-[clamp(120px,38vw,560px)] overflow-hidden rounded-[46%_54%_58%_42%/52%_46%_54%_48%] border border-line bg-mist ring-1 ring-line">
              <img
                src={portrait}
                alt="Portrait de Fethi Selles"
                loading="eager"
                className="h-full w-full scale-105 object-cover object-top grayscale-[20%] transition-all duration-500 ease-out group-hover:scale-110 group-hover:grayscale-0"
              />
            </div>
          </figure>
        </div>

        <p className="mt-6 font-mono text-[11px] uppercase tracking-[0.16em] text-ink sm:text-sm">
          Étudiant en médecine
          <span className="mx-1.5 text-crimson">·</span>Bio-informatique
          <span className="mx-1.5 text-crimson">·</span>Communication scientifique
        </p>

        <div className="mt-8 max-w-2xl">
          <p className="font-display text-2xl font-semibold leading-tight tracking-tight md:text-[2rem]">
            Médecine <span className="text-crimson">×</span> Technologie{' '}
            <span className="text-crimson">×</span> Humain.
          </p>
          <p className="mt-5 text-base leading-relaxed text-muted md:text-lg">
            Je travaille à l'intersection de la science, de la technologie et des relations humaines
            : traduire des idées scientifiques complexes en projets concrets, coordonner des équipes
            et faire dialoguer les institutions.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href="#experience"
              className="group inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 font-display text-sm font-semibold text-white transition-colors hover:bg-crimson"
            >
              Découvrir mon parcours
              <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-full border border-line px-6 py-3 font-display text-sm font-semibold text-ink transition-colors hover:border-ink"
            >
              Me contacter
            </a>
          </div>
        </div>

        {/* Verified stats */}
        <dl className="mt-14 grid grid-cols-3 gap-4 border-t border-line pt-6 md:mt-16">
          {STATS.map((s) => (
            <div key={s.k}>
              <dt className="font-display text-2xl font-bold tracking-tight text-ink md:text-4xl">
                {s.k}
              </dt>
              <dd className="mt-1 text-xs leading-snug text-muted md:text-sm">{s.v}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-14 flex items-center gap-4 border-t border-line py-5 md:mt-16">
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-muted">
            Learn · Connect · Serve · Impact
          </span>
          <span className="ml-auto hidden font-mono text-xs text-muted sm:block">↓ Défiler</span>
        </div>
      </div>
    </section>
  )
}
