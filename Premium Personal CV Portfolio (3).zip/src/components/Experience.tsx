import { useState } from 'react'
import { useReveal } from '../lib/useReveal'
import { SectionHeader } from './SectionHeader'

type Role = {
  period: string
  role: string
  org: string
  place: string
  points: string[]
  tag: string
}

const ROLES: Role[] = [
  {
    period: '2025 — présent',
    role: 'Manager des Relations Extérieures',
    org: 'Tyriaq',
    place: 'Algérie',
    tag: 'Relations',
    points: [
      "Pilotage des relations avec les partenaires externes et représentation de l'organisation.",
      "Négociation d'accords et de partenariats stratégiques.",
    ],
  },
  {
    period: 'Oct. 2025 — présent',
    role: 'Spécialiste Événements',
    org: 'Quanta Club',
    place: 'Algérie',
    tag: 'Événementiel',
    points: [
      "Conception et coordination d'événements de bout en bout : logistique, partenaires, communication.",
      'Interface avec les intervenants et les sponsors pour garantir la qualité des événements.',
    ],
  },
  {
    period: 'Mai 2025 — présent',
    role: 'Assistant — Temps partiel',
    org: 'Umed Academy',
    place: 'Alger, Algérie',
    tag: 'Coordination',
    points: [
      "Appui à la gestion et à la coordination des activités de l'équipe pédagogique.",
      "Compétence développée : management et travail d'équipe.",
    ],
  },
  {
    period: '2024 — présent',
    role: 'Médecin externe',
    org: 'Cursus de médecine',
    place: 'Alger, Algérie',
    tag: 'Clinique',
    points: [
      'Stages hospitaliers pratiques dans le cadre du cursus de médecine.',
      'Application des connaissances en médecine et bio-informatique en contexte clinique.',
    ],
  },
  {
    period: 'Sept. 2025 — Fév. 2026',
    role: 'Délégué de la promo',
    org: "Université d'Alger",
    place: 'Algérie · Sur site',
    tag: 'Leadership',
    points: [
      'Interlocuteur entre les étudiants et le corps enseignant/administratif.',
      'Compétence développée : management et leadership.',
    ],
  },
  {
    period: 'Juil. — Août 2025',
    role: 'Tuteur en ligne',
    org: 'Indépendant',
    place: 'À distance',
    tag: 'Pédagogie',
    points: ['Accompagnement pédagogique personnalisé à distance.'],
  },
  {
    period: 'Janv. 2022 — Janv. 2024',
    role: 'Joueur — Équipe nationale de volleyball',
    org: 'Sélection nationale',
    place: 'Algérie · Temps partiel',
    tag: 'Sport',
    points: [
      "Vice-champion d'Algérie de volleyball — 2023.",
      "Discipline, esprit d'équipe et gestion de la pression développés au niveau national.",
    ],
  },
]

function Item({ r, i }: { r: Role; i: number }) {
  const [open, setOpen] = useState(i === 0)
  return (
    <div className="border-b border-line">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="group grid w-full grid-cols-[auto_1fr_auto] items-center gap-4 py-6 text-left md:gap-8"
      >
        <span className="hidden w-40 shrink-0 font-mono text-xs uppercase tracking-wider text-muted md:block">
          {r.period}
        </span>
        <span className="min-w-0">
          <span className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className="font-display text-lg font-semibold tracking-tight transition-colors group-hover:text-crimson md:text-xl">
              {r.role}
            </span>
            <span className="rounded-full bg-mist px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted">
              {r.tag}
            </span>
          </span>
          <span className="mt-1 block text-sm text-muted">
            {r.org} · {r.place}
          </span>
          <span className="mt-1 block font-mono text-[11px] uppercase tracking-wider text-muted md:hidden">
            {r.period}
          </span>
        </span>
        <span
          className={`grid h-8 w-8 shrink-0 place-items-center rounded-full border border-line text-muted transition-all group-hover:border-crimson group-hover:text-crimson ${
            open ? 'rotate-45' : ''
          }`}
          aria-hidden
        >
          +
        </span>
      </button>
      <div
        className={`grid overflow-hidden transition-all duration-300 ${
          open ? 'grid-rows-[1fr] pb-6' : 'grid-rows-[0fr]'
        }`}
      >
        <ul className="min-h-0 space-y-2 md:pl-48">
          {r.points.map((p) => (
            <li key={p} className="flex gap-3 text-sm leading-relaxed text-muted">
              <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-crimson" />
              {p}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

export function Experience() {
  const ref = useReveal<HTMLDivElement>()
  return (
    <section id="experience" className="scroll-mt-24 bg-mist py-24 md:py-32">
      <div ref={ref} className="reveal mx-auto max-w-[1240px] px-6 md:px-10">
        <SectionHeader index="02" eyebrow="Parcours" title={<>Expérience professionnelle &amp; associative</>}>
          <p className="text-lg leading-relaxed text-muted">
            Sept engagements menés en parallèle des études : relations, événementiel, clinique,
            représentation et sport de haut niveau. Cliquez pour déplier chaque rôle.
          </p>
        </SectionHeader>

        <div className="mt-14 border-t border-line">
          {ROLES.map((r, i) => (
            <Item key={r.role} r={r} i={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
