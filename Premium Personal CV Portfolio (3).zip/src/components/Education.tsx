import { useReveal } from '../lib/useReveal'
import { SectionHeader } from './SectionHeader'

const EDU = [
  {
    period: 'En cours · 2 ans 9 mois',
    title: 'Doctorat en Médecine',
    org: 'Université des Sciences Médicales — Alger, Algérie',
  },
  {
    period: 'En cours · 2 ans 9 mois',
    title: 'Licence en Bio-informatique',
    org: "Université d'Alger — Alger, Algérie",
  },
  {
    period: '2024',
    title: 'Baccalauréat, série Scientifique',
    org: 'Moyenne obtenue : 18,14/20',
  },
]

const CERTS = [
  { title: 'Google Prompting Essentials', org: 'Google', meta: "Valide jusqu'en juin 2026" },
  { title: 'Cancer Biology Specialization', org: 'Johns Hopkins University', meta: 'Certification' },
]

export function Education() {
  const ref = useReveal<HTMLDivElement>()
  return (
    <section id="education" className="scroll-mt-24 bg-mist py-24 md:py-32">
      <div ref={ref} className="reveal mx-auto max-w-[1240px] px-6 md:px-10">
        <SectionHeader index="04" eyebrow="Formation" title={<>Formation &amp; certifications</>} />

        <div className="mt-16 grid gap-16 md:grid-cols-2">
          <div>
            <h3 className="font-mono text-xs uppercase tracking-[0.2em] text-crimson">Diplômes</h3>
            <div className="mt-6 space-y-8">
              {EDU.map((e) => (
                <div key={e.title} className="border-l-2 border-line pl-5">
                  <div className="font-mono text-xs uppercase tracking-wider text-muted">
                    {e.period}
                  </div>
                  <div className="mt-2 font-display text-xl font-semibold tracking-tight">
                    {e.title}
                  </div>
                  <div className="mt-1 text-sm text-muted">{e.org}</div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-mono text-xs uppercase tracking-[0.2em] text-crimson">
              Certifications
            </h3>
            <div className="mt-6 space-y-4">
              {CERTS.map((c) => (
                <div
                  key={c.title}
                  className="flex items-start justify-between gap-4 rounded-xl border border-line bg-paper p-5 transition-colors hover:border-crimson"
                >
                  <div>
                    <div className="font-display text-base font-semibold tracking-tight">
                      {c.title}
                    </div>
                    <div className="mt-1 text-sm text-muted">{c.org}</div>
                  </div>
                  <span className="shrink-0 font-mono text-[11px] uppercase tracking-wider text-muted">
                    {c.meta}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
