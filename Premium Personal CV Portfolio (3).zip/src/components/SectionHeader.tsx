import type { ReactNode } from 'react'

export function SectionHeader({
  index,
  eyebrow,
  title,
  children,
}: {
  index: string
  eyebrow: string
  title: ReactNode
  children?: ReactNode
}) {
  return (
    <div className="grid gap-6 md:grid-cols-12">
      <div className="md:col-span-4">
        <div className="flex items-baseline gap-3">
          <span className="font-mono text-sm text-crimson">{index}</span>
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-muted">{eyebrow}</span>
        </div>
        <h2 className="mt-4 font-display text-[clamp(2rem,4vw,3.25rem)] font-bold leading-[0.98] tracking-[-0.02em]">
          {title}
        </h2>
      </div>
      {children && (
        <div className="self-end md:col-span-7 md:col-start-6">{children}</div>
      )}
    </div>
  )
}
