import { useEffect, useRef, useState } from 'react'
import { useReveal } from '../lib/useReveal'
import { SectionHeader } from './SectionHeader'

const BARS = [
  {
    label: 'Négociation & partenariats',
    level: 92,
    note: 'Expert',
    evidence: "Accords et partenariats stratégiques pilotés en relations extérieures.",
  },
  {
    label: 'Gestion événementielle',
    level: 90,
    note: 'Expert',
    evidence: "Événements coordonnés de bout en bout : logistique, intervenants, sponsors.",
  },
  {
    label: 'Communication',
    level: 90,
    note: 'Expert',
    evidence: 'Interface partenaires, représentation et communication institutionnelle.',
  },
  {
    label: 'Leadership & management',
    level: 86,
    note: 'Avancé',
    evidence: "Représentant de classe, management d'équipe et sport de haut niveau.",
  },
  {
    label: 'Prompt engineering',
    level: 80,
    note: 'Avancé',
    evidence: 'Certifié Google Prompting Essentials (2026).',
  },
  {
    label: 'Design graphique',
    level: 74,
    note: 'Confirmé',
    evidence: 'Conception de supports visuels pour projets et événements.',
  },
]

const GROUPS = [
  {
    title: 'Relations & Négociation',
    items: ['Relations extérieures', 'Partenariats & sponsors', 'Représentation institutionnelle'],
  },
  {
    title: 'Événementiel & Gestion',
    items: ['Coordination logistique', 'Gestion de projet', 'Interface intervenants'],
  },
  {
    title: 'Science & Clinique',
    items: ['Bio-informatique médicale', 'Externat hospitalier', 'Recherche & rigueur'],
  },
  {
    title: 'Numérique & Pédagogie',
    items: ['Prompt engineering', 'Design graphique', 'Tutorat & pédagogie'],
  },
]

const LANGS = [
  { l: 'Arabe', lvl: 'Langue maternelle' },
  { l: 'Français', lvl: 'Courant' },
  { l: 'Anglais', lvl: 'Professionnel' },
]

function Bar({
  label,
  level,
  note,
  evidence,
  delay,
}: {
  label: string
  level: number
  note: string
  evidence: string
  delay: number
}) {
  const ref = useRef<HTMLDivElement>(null)
  const [shown, setShown] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setShown(true)
          io.disconnect()
        }
      },
      { threshold: 0.4 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])
  return (
    <div ref={ref}>
      <div className="flex items-baseline justify-between">
        <span className="font-display text-sm font-semibold tracking-tight">{label}</span>
        <span className="font-mono text-[11px] uppercase tracking-wider text-muted">{note}</span>
      </div>
      <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-line">
        <div
          className="h-full rounded-full bg-crimson transition-[width] duration-1000 ease-out"
          style={{ width: shown ? `${level}%` : '0%', transitionDelay: `${delay}ms` }}
        />
      </div>
      <p className="mt-2.5 text-xs leading-relaxed text-muted">{evidence}</p>
    </div>
  )
}

export function Skills() {
  const ref = useReveal<HTMLDivElement>()
  return (
    <section id="skills" className="scroll-mt-24 py-24 md:py-32">
      <div ref={ref} className="reveal mx-auto max-w-[1240px] px-6 md:px-10">
        <SectionHeader index="03" eyebrow="Compétences" title={<>Un savoir-faire à double culture.</>}>
          <p className="text-lg leading-relaxed text-muted">
            Des forces éprouvées sur le terrain associatif, clinique et sportif — évaluées avec
            honnêteté et regroupées par domaine.
          </p>
        </SectionHeader>

        <div className="mt-16 grid gap-12 lg:grid-cols-12">
          {/* Proficiency bars */}
          <div className="lg:col-span-7">
            <h3 className="mb-8 font-mono text-xs uppercase tracking-[0.2em] text-crimson">
              Forces signatures
            </h3>
            <div className="grid gap-7 sm:grid-cols-2">
              {BARS.map((b, i) => (
                <Bar key={b.label} {...b} delay={i * 90} />
              ))}
            </div>
          </div>

          {/* Grouped skills */}
          <div className="lg:col-span-5">
            <h3 className="mb-8 font-mono text-xs uppercase tracking-[0.2em] text-crimson">
              Domaines
            </h3>
            <div className="grid gap-8 sm:grid-cols-2">
              {GROUPS.map((g) => (
                <div key={g.title}>
                  <h4 className="border-b border-line pb-2.5 font-display text-sm font-semibold tracking-tight">
                    {g.title}
                  </h4>
                  <ul className="mt-3 space-y-2">
                    {g.items.map((it) => (
                      <li key={it} className="flex items-center gap-2 text-sm text-muted">
                        <span className="h-1 w-1 shrink-0 rounded-full bg-crimson" />
                        {it}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-6 rounded-2xl bg-ink p-8 text-white md:flex-row md:items-center md:justify-between md:p-10">
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-white/60">Langues</span>
          <div className="grid flex-1 grid-cols-1 gap-6 sm:grid-cols-3 md:max-w-2xl">
            {LANGS.map((x) => (
              <div key={x.l}>
                <div className="font-display text-xl font-semibold">{x.l}</div>
                <div className="mt-1 text-sm text-white/60">{x.lvl}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
