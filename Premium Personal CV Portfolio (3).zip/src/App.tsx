import { Nav } from './components/Nav'
import { Hero } from './components/Hero'
import { Proof } from './components/Proof'
import { About } from './components/About'
import { Experience } from './components/Experience'
import { Skills } from './components/Skills'
import { Education } from './components/Education'
import { Contact } from './components/Contact'

export default function App() {
  return (
    <div className="min-h-screen bg-paper text-ink font-body antialiased">
      <Nav />
      <main>
        <Hero />
        <Proof />
        <About />
        <Experience />
        <Skills />
        <Education />
        <Contact />
      </main>
    </div>
  )
}
